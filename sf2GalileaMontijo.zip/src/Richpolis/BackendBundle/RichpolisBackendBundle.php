<?php

namespace Richpolis\BackendBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class RichpolisBackendBundle extends Bundle
{
}
