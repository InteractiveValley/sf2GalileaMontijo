<?php

namespace Richpolis\GalMonBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class RichpolisGalMonBundle extends Bundle
{
}
